<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit;

global $articleContent;
if ($this->is('single')) {
    $articleContent = $this->content;
}

?>
<?php $this->need('header.php'); ?>



<div class="article banner top">

<?php if ($this->fields->banner === "show") : ?>
<img class="bg lazy" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAAaADAAQAAAABAAAAAQAAAADa6r/EAAAAC0lEQVQIHWNgAAIAAAUAAY27m/MAAAAASUVORK5CYII=" data-src="<?php $this->fields->image(); ?>">
<?php endif; ?>

<div class="content">
<div class="top bread-nav footnote">
<div class="left">
<div class="flex-row" id="breadcrumb">
<a class="cap breadcrumb" href="/">主页</a>
<span class="sep"></span>
<a class="cap breadcrumb" href="/">文章</a><span class="sep"></span>
<?php $this->category(','); ?>
</div>

<div class="flex-row" id="post-meta">
<a class="author" href="/author/<?php $this->authorId(); ?>">
<?php $this->author(); ?>
</a>

<span class="sep"></span>
<span class="text created">
<time datetime="2024-02-09T09:02:44.000Z"><?php $this->date('Y-m-d'); ?></time></span>
<span class="sep updated"></span>
<span class="text updated">更新于：<time datetime="2024-04-25T01:18:14.747Z"><?php echo date('Y-m-d H:i:s' , $this->modified); ?></time></span></div>


<div class="flex-row" id="breadcrumb">
<span class="text"><?php Postviews($this); ?></span>
</div>

</div></div>

    
    <div class="bottom only-title">
      
      <div class="text-area">
        <h1 class="text title"><span><?php $this->title() ?></span></h1>
<div class="text subtitle">
<?php if ($this->fields->subtitle()): ?>
<?php $this->fields->subtitle(); ?>
<?php endif; ?>
</div>        
      </div>
    </div>
    
  </div>


  

</div>




<article class="md-text content">


<?php if (is_array($this->options->sidebarBlock) && in_array('Showhuanying3', $this->options->sidebarBlock)): ?>
<div class="tp-ad-text1">
<?php $this->options->文章广告(); ?>
</div>
<?php endif; ?>





<?php $this->content(); ?>

<?php 
foreach($this->tags as $val){
    ?>
<a href="<?php echo $val['url']; ?>" itemprop="url" color="<?php if ($this->fields->tagcolor()): ?>
<?php $this->fields->tagcolor(); ?><?php endif; ?>" class="tag-plugin colorful hashtag"><?php echo $val['name']; ?></a>
<?php } ?>

<div class="article-footer fs14">
    <section id="license">
      <div class="header"><span>许可协议</span></div>
      <div class="body"><p>本文采用 <a target="_blank" rel="noopener external nofollow noreferrer" href="https://creativecommons.org/licenses/by-nc-sa/4.0/">署名-非商业性使用-相同方式共享 4.0 国际</a> 许可协议，转载请注明出处。</p>
</div>
    </section>
    </div>
</article>



<div class="related-wrap" id="read-next"><section class="body"><div class="item" id="prev"><div class="note">较新文章</div><?php $this->theNext(); ?></div><div class="item" id="next"><div class="note">较早文章</div><?php $this->thePrev(); ?></div></section></div>



<?php $this->need('comments.php'); ?>

<?php $this->need('footer.php'); ?>
